# Stalemate viewer with fixed-engine twins

This is the same viewer as `../turn_viewer/` ("Stalemate segments", v2) with two more games in its game list. The viewer
code is unchanged. Only the embedded game list, the heading and sub line, and the note text below the charts are
different. Games load by script tag from `games/`, the page makes no external requests, and it works from `file://`.

## The four games
All four are v049200 against itself (`uncapped/ck/v049200.pt`), playing uncapped fresh-start games with actions
sampled at temperature 1.

| # | File | What it is |
|---|------|------------|
| 1 | `games/g01.js` (2.4 MB) | Normal roster, seed 1001, env 7, on the engine as of 12 Nov (frozen snapshot 24497128d3c6ac0d). 2,700 decisions (6:01) from 2:00:00. Byte-identical to the original. |
| 2 | `games/g02.js` (2.7 MB) | Swapped roster, seed 1002, env 4, same engine and window as #1. Byte-identical to the original. |
| 3 | `games/g03.js` (2.8 MB) | The same seed, env, roster and checkpoint as #1, run on the fixed engine (fastsim source at commit ad267e5f with the certified `lib_fix2_pgo.so`, md5 6b23a388...). The whole game from 0:00 to the nexus kill, with a frame every 10th decision. |
| 4 | `games/g04.js` (2.8 MB) | The same seed, env, roster and checkpoint as #2, on the fixed engine. The whole game, with a frame every 13th decision. |

The viewer takes its clock from each frame's game time, so the time display is correct with these strides. The hint
line under the map gives the stride.

## Fixed-engine results
| | #3 (seed 1001, normal) | #4 (seed 1002, swapped) |
|---|---|---|
| End | CHAOS destroys the ORDER nexus at 44:13 (19,902 decisions) | CHAOS destroys the ORDER nexus at 56:12 (25,308 decisions) |
| Kills ORDER-CHAOS | 25-22 | 27-41 |
| Turrets lost ORDER-CHAOS | 9-8 (ORDER's includes both nexus turrets) | 10-10 (both teams lost both nexus turrets) |
| Inhibitors lost ORDER-CHAOS | 2-1 | 2-2 |
| Peak lane minions alive ORDER / CHAOS | 55 / 50 | 52 / 61 |
| Nexus targetable | ORDER's nexus opened at decision 18,915 and stayed open until it died. CHAOS's never opened. | CHAOS's nexus opened at decision 17,058 and **re-locked** at 17,330 when its inhibitors respawned. It never opened again. ORDER's nexus opened at 25,247 and died 61 decisions later. |
| Minion evictions / pool overflows | 0 / 0 | 0 / 0 |

In the "Turrets lost" counts, the viewer's turret labels count the inhibitor turrets ("mid inhib", etc.) as turrets,
the same way as for games #1 and #2.

## Seeds
These runs used the same recorder code path as the originals: a copy of `interp/D/long.py` with the same flags,
128 envs per run, `--threads 2`, the same policy forward, and Gumbel noise from one CUDA generator seeded with
seed + 11. On the 12 Nov snapshot, this copy reproduces the original runs bit for bit. At decision 4500, the
observations, masks and LSTM states of all 128 envs in both seeds matched the originals' saved state dumps exactly.
On the fixed engine the same seeds diverge early: by decision 4500 (10:00), env 7 and env 4 already differ from the
originals. So games #3 and #4 share their seed with #1 and #2, but they are not the same game.

## Putting it in the blog
Same as `../turn_viewer/`: copy `index.html` and `games/` together. `../turn_viewer/snippet.html` still works. The full
download is about 10.8 MB if a reader opens all four games, but each game loads only when it is selected.
